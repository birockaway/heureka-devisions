# scraper_he

Scraper for herueka's cz and sk versions.

*For support ask at bi@ecommerceholding.cz*
